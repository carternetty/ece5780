clear
g++ *.cpp -o scheduler.exe
./scheduler.exe input.txt output.txt
